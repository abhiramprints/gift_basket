package Automation_HCL_LMS_Invalid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class InvalidLogin {
	WebDriver driver;
	@BeforeTest
	@Parameters("browser")
	public void setUp(String browserName)throws Exception{
		if(browserName.equalsIgnoreCase("edge")){
		    System.setProperty("webdriver.edge.driver","C:\\Users\\tushar.prabhakar\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		    driver=new EdgeDriver();
		    driver.get("https://www.hcltss-lms.com/login/index.php");
		    driver.manage().window().maximize();
		    System.out.println("Title of the page is: "+driver.getTitle());
		}
		else if(browserName.equalsIgnoreCase("chrome")){
		    System.setProperty("webdriver.chrome.driver","C:\\Users\\tushar.prabhakar\\Downloads\\chromedriver_win32\\chromedriver.exe");
		    driver=new ChromeDriver();
		    driver.get("https://www.hcltss-lms.com/login/index.php");
		    driver.manage().window().maximize();
		    System.out.println("Title of the page is: "+driver.getTitle());
		}
	}
		
	@Test
	public void testWeb()throws Exception{
		
		if(driver.findElement(By.name("username")).isDisplayed()){
		    System.out.println("Username textbox is present");
		    driver.findElement(By.name("username")).sendKeys("LTTB08213657");
		    System.out.println("Entered Invalid username is: LTTB08213657");
		}
		else{
		    System.out.println("The username textbox is not present.");
		}
		if(driver.findElement(By.name("password")).isDisplayed()){
		    System.out.println("Password textbox is present");
		    driver.findElement(By.name("password")).sendKeys("P@ssw0rde");
		    System.out.println("Entered Invalid password is: P@ssw0rde");
		}
		else{
		    System.out.println("The password textbox is not present.");
		}
		if(driver.findElement(By.id("loginbtn")).isEnabled()){
		    System.out.println("Login button is present");
		    driver.findElement(By.id("loginbtn")).click();
		    System.out.println("Login button is clicked");
		}
		else{
		    System.out.println("The login button is not present.");
		}
		
		if(driver.getTitle().contains("Learner Landing")){
		    System.out.println("Title of the page is:"+driver.getTitle());
		    System.out.println("Login successful");
		}
		else{
		    System.out.println("Login failed");
		}
	}
	
	@AfterTest
	public void tearDown() throws Exception{
		driver.quit();
	}
}