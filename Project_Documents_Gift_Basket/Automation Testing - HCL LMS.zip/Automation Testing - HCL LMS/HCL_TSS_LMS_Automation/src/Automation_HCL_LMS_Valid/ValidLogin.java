package Automation_HCL_LMS_Valid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ValidLogin {
	public void verifyLogin(WebDriver wd){
		WebDriver driver=wd;
		driver.manage().window().maximize();
		driver.get("https://www.hcltss-lms.com/login/index.php");
		System.out.println("Title of the page is: "+driver.getTitle());
		
		if(driver.findElement(By.name("username")).isDisplayed()){
			System.out.println("Username textbox is present");
			driver.findElement(By.name("username")).sendKeys("VJWTB0721203");
			System.out.println("Entered username is: VJWTB0721203");
		}
		else{
			System.out.println("The username textbox is not present.");
		}
		
		if(driver.findElement(By.name("password")).isDisplayed()){
			System.out.println("Password textbox is present");
			driver.findElement(By.name("password")).sendKeys("P@ssw0rd");
			System.out.println("Entered password is: P@ssw0rd");
		}
		else{
			System.out.println("The password textbox is not present.");
		}
		
		if(driver.findElement(By.id("loginbtn")).isEnabled()){
			System.out.println("Login button is present");
			driver.findElement(By.id("loginbtn")).click();
			System.out.println("Login button is clicked");
		}
		else{
			System.out.println("The login button is not present.");
		}
		
		if(driver.getTitle().contains("Learner Landing")){
			System.out.println("Title of the page is:"+driver.getTitle());
			System.out.println("Login successfull");
		}
		
		else{
		System.out.println("Login failed");
		}
	}
}