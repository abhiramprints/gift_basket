package Automation_HCL_LMS_Valid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Feedback {
	WebDriver driver;
	
	@BeforeTest
	@Parameters("browser")
	public void setUp(String browserName) {
		// Cross Browser Testing
		if(browserName.equalsIgnoreCase("edge")) {
			System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
			driver= new EdgeDriver();
		}
		else if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
			driver= new ChromeDriver();
		}
		
		//Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
	}
	
	@Test
	public void verifyPageTitle(){
		//Learner's Landing
		if(driver.findElement(By.cssSelector("#navbarSupportedContent > ul > li:nth-child(4) > a")).isDisplayed()){
			driver.findElement(By.cssSelector("#navbarSupportedContent > ul > li:nth-child(4) > a")).click();
			System.out.println("Automation Testing for Learner's Landing completed successfully");
		}
		else
            System.out.println("Feedback Form is not displayed");
		
		//Feedback form
		System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/p[1]")).getText());
		System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/p[2]")).getText());
		
		//Course
		if(driver.findElement(By.id("crs")).isDisplayed()){
			WebElement crs = driver.findElement(By.id("crs"));
			Select crs1 = new Select(crs);
			crs1.selectByValue("Testing");
		}
		else
            System.out.println("Course is not displayed");
		//Week No
		if(driver.findElement(By.cssSelector("#wks")).isDisplayed()){
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement wks = driver.findElement(By.cssSelector("#wks"));
			Select wks1 = new Select(wks);
			wks1.selectByVisibleText("Week15");
		}
		else
            System.out.println("Week is not displayed");
		//Trainer
		if(driver.findElement(By.id("trn")).isDisplayed()){
			WebElement trn = driver.findElement(By.id("trn"));
			Select trn1 = new Select(trn);
			trn1.selectByValue("Nageswarrao");
		}
		else
            System.out.println("Trainer is not displayed");
		
		//Feedback on Trainer
		
		//The Trainer explained concepts effectively
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[5]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[5]")).click();
		else
            System.out.println("The Trainer explained concepts effectively is not displayed");
		//The Trainer helped effectively in Lab / exercises / activities
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[10]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[10]")).click();
		else
            System.out.println("The Trainer helped effectively in Lab / exercises / activities is not displayed");
		//The Trainer encouraged us to ask questions
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[14]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[14]")).click();
		else
            System.out.println("The Trainer encouraged us to ask questions is not displayed");
		//The Trainer answered questions effectively
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[18]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[18]")).click();
		else
            System.out.println("The Trainer answered questions effectively is not displayed");
		//The Trainer conducted the Course at a pace that was comfortable
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[22]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[22]")).click();
		else
            System.out.println("The Trainer conducted the Course at a pace that was comfortable is not displayed");
		//The Trainer made the Course interesting and easy to understand
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[26]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[26]")).click();
		else
            System.out.println("The Trainer made the Course interesting and easy to understand is not displayed");
		//The Trainer ensured that the Learning Objectives of the Course were met
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[33]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[33]")).click();
		else
            System.out.println("The Trainer ensured that the Learning Objectives of the Course were met is not displayed");
		//Comments
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[1]")).isDisplayed()){
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[1]")).sendKeys("The Trainer explained the concepts well in an effective way.");
			System.out.println("Trainer Feedback Written");
		}
		else
            System.out.println("Comments is not displayed");
		
		//Feedback on Content
		
		//The Content was relevant to the Learning Objectives
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[40]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[40]")).click();
		else
            System.out.println("The Content was relevant to the Learning Objectives is not displayed");
		//The Content covered all Topics & sub-topics relevant for the Course
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[44]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[44]")).click();
		else
            System.out.println("The Content covered all Topics & sub-topics relevant for the Course is not displayed");
		//The Content explained all concepts clearly
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[48]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[48]")).click();
		else
            System.out.println("The Content explained all concepts clearly is not displayed");
		//The Content had ample examples illustrating concepts
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[53]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[53]")).click();
		else
            System.out.println("The Content had ample examples illustrating concepts is not displayed");
		//The Flow of Topics & sub-topics helped Understanding & Learning
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[56]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[56]")).click();
		else
            System.out.println("The Flow of Topics & sub-topics helped Understanding & Learning is not displayed");
		//Comments
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[2]")).isDisplayed()){
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[2]")).sendKeys("The Content made us understand the Topics very well.");
			System.out.println("Content Feedback Written");
		}
		else
            System.out.println("Comments is not displayed");
		
		//Feedback on LMS
		
		//The LMS was accessible when needed
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[63]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[63]")).click();
		else
            System.out.println("The LMS was accessible when needed is not displayed");
		//The speed of upload was good
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[69]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[69]")).click();
		else
            System.out.println("The speed of upload was good is not displayed");
		//It was easy to use the LMS and complete Exercises & Assessments
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[75]")).isDisplayed())
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/input[75]")).click();
		else
            System.out.println("It was easy to use the LMS and complete Exercises & Assessments is not displayed");
		//Comments
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[3]")).isDisplayed()){
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/form/textarea[3]")).sendKeys("The LMS is working perfect and the response is also fast.");
			System.out.println("LMS Feedback Written");
		}
		else
            System.out.println("Comments is not displayed");
		
		//Submit button
		if(driver.findElement(By.id("id_submitbutton")).isDisplayed()){
			driver.findElement(By.id("id_submitbutton")).click();
			System.out.println("Submit Button Clicked");
		}
		else
            System.out.println("Submit Button is not displayed");
	}
	
	@AfterTest
	public void tearDown() {
		//Printing the active page's Title
		if(driver.getTitle().contains("Scholar Feedback")) {
			System.out.println("Process completed");
		}
		else
			System.out.println("Process not completed");
		System.out.println("Tested by K Abhiram");
		
		//Closing the active browser
		driver.quit();
		//K Abhiram
	}
}