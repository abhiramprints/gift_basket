package Automation_HCL_LMS_Valid;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
        
public class Testing_Set{
    WebDriver driver;
    
    @BeforeTest
    @Parameters("browser")
    public void setUp(String browserName) {
        //Cross Browser Testing
        if(browserName.equalsIgnoreCase("edge")) {
            System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
            driver= new EdgeDriver();
        }
        else if(browserName.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
            driver= new ChromeDriver();
        }
        //Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
    }
    
    @Test
    public void testWeb(){
        //Learner's Landing
        if(driver.findElement(By.xpath("//*[@id=\"region-main\"]/div/div/div/div[2]/div[3]/div[5]/div/div/a/strong")).isDisplayed()){
            driver.findElement(By.xpath("//*[@id=\"region-main\"]/div/div/div/div[2]/div[3]/div[5]/div/div/a/strong")).click();
            //Testing Set
            for(String winHandle : driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
            }
            System.out.println(driver.getTitle()+" opened");
            System.out.println("Automation Testing for Learner's Landing completed successfully");
        }
        else
            System.out.println("Testing course is not displayed");

        //Testing Module
        if(driver.findElement(By.cssSelector("#section-outline-175 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-175 > a")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("Testing Fundamentals: Man... is not displayed");

        //Testing Fundamentals
        if(driver.findElement(By.cssSelector("#section-outline-176 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-176 > a")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("Topic 1-SOFTWARE DEVELOPM... is not displayed");

        //Software Development Life Cycle
        if(driver.findElement(By.cssSelector("#module-580039 > div > div > div:nth-child(2) > div.activityinstance > a > span")).isDisplayed()){
            driver.findElement(By.cssSelector("#module-580039 > div > div > div:nth-child(2) > div.activityinstance > a > span")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("SDLC is not displayed");

        //In Class Content
        if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isDisplayed()){
            if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isEnabled()){
                driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).click();
                driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            }
        }
        else
            System.out.println("Enter button is not displayed");

        //Scorm ppt
        if(driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).isDisplayed()){
            if(driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).isEnabled()){
                driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).click();
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                System.out.println("Automation Testing for Testing module completed successfully");
            }
        }
        else
            System.out.println("Exit Activity button is not displayed");

        //SQL Module
        if(driver.findElement(By.cssSelector("#section-outline-404 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-404 > a")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("SQL-Module 3 is not displayed");
        //SQL
        if(driver.findElement(By.cssSelector("#section-outline-413 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-413 > a")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("Topic 02-DDL is not displayed");
        //DDL
        if(driver.findElement(By.cssSelector("#module-580156 > div > div > div:nth-child(2) > div.activityinstance > a > span")).isDisplayed()){
            driver.findElement(By.cssSelector("#module-580156 > div > div > div:nth-child(2) > div.activityinstance > a > span")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        else
            System.out.println("DDL is not displayed");

        //In Class Content
        if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isDisplayed()){
            if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isEnabled()){
                driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).click();
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            }
        }
        else
            System.out.println("Enter button is not displayed");

        //Scorm ppt
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        System.out.println(driver.getTitle()+" opened");
        driver.close();
        System.out.println("Automation Testing for SQL module completed successfully");

        //Navbar - LogOut
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        driver.findElement(By.id("action-menu-toggle-0")).click();
        driver.findElement(By.xpath("//*[@id=\"action-menu-0-menu\"]/a[6]")).click();
    }
    
    @AfterTest
    public void tearDown() {
        //Printing the active page's Title
        if(driver.getTitle().contains("HCL TRAINING AND STAFFING SERVICES: Log in to the site")) {
            System.out.println("Process completed");
        }
        else
            System.out.println("Process not completed");
        System.out.println("Tested by K Abhiram");
        //Closing the active browser
        driver.quit();
        //K Abhiram
    }
}