package Automation_HCL_LMS_Valid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Resources {
	WebDriver driver;
	
	@BeforeTest
	@Parameters("browser")
	public void setUp(String browserName) {
		// Cross Browser Testing
		if(browserName.equalsIgnoreCase("edge")) {
			System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
			driver= new EdgeDriver();
		}
		else if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
			driver= new ChromeDriver();
		}
		
		//Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
	}
	
	@Test
	public void testWeb() {
		//Clicking HCL Logo
		if(driver.findElement(By.xpath("//*[@id=\"page-wrapper\"]/div[2]/div/nav/div[1]/a/img")).isDisplayed()){
			driver.findElement(By.xpath("//*[@id=\"page-wrapper\"]/div[2]/div/nav/div[1]/a/img")).click();
			System.out.println("HCL Logo clicked");
		}
		else
			System.out.println("HCL Logo is not displayed");
		
		//Clicking Resources
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(driver.findElement(By.linkText("Resources")).isDisplayed()) {
			System.out.println("Resources is present");
			driver.findElement(By.linkText("Resources")).click();
		}
		
		else {
			System.out.println("Resources is not present");
		}
		
		//Clicking V&A Lab
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(driver.findElement(By.linkText("V&A LAB")).isDisplayed()) {
			System.out.println("Vlab is present");
			driver.findElement(By.linkText("V&A LAB"));
		}
		
		else {
			System.out.println("VLab is not present");
		}	
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().back();
		System.out.println("V&A lab working fine!");
	}
	
	@AfterTest
	public void tearDown() {
		//Printing the active page's Title
		if(driver.getTitle().contains("Learner Landing")) {
			System.out.println("Process completed");
		}
		else
			System.out.println("Process not completed");
		System.out.println("Tested by K Abhiram");
		
		//Closing the active browser
		driver.quit();
		//K Abhiram
	}
}
