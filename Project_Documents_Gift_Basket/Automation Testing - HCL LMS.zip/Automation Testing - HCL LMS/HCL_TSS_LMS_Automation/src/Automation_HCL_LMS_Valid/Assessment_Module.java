package Automation_HCL_LMS_Valid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class Assessment_Module {
	WebDriver driver;
	
	@Parameters("browser")
	@BeforeTest
	public void setUp(String browserName){
		if(browserName.equalsIgnoreCase("edge")){
			System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
			driver= new EdgeDriver();
		}
		
		else if(browserName.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
			driver= new ChromeDriver();
		}
		
		//Login
		ValidLogin vl=new ValidLogin();
		vl.verifyLogin(driver);
	}
	
	
	
	@Test
	public void testWeb(){
		//Assessment
		if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div/section/div/div/div/div[3]/div/div[4]/div/div[1]/div[2]/a")).isDisplayed()){
			System.out.println("Assessments tab is opened");
			
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div/section/div/div/div/div[3]/div/div[4]/div/div[1]/div[2]/a")).click();
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			
			if(driver.findElement(By.cssSelector("#section-outline-1 > a")).isDisplayed()){
				System.out.println("Assessment 1 is displayed");
				driver.findElement(By.cssSelector("#section-outline-1 > a")).click();
				
				if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/div/div/ul/li/div/div/ul/li[5]/div/div/div[2]/div/a/span")).isDisplayed())
				{
				System.out.println("TTT_C&PST_TB_QUIZ_WEEK_12 page is opened ");
				driver.findElement(By.cssSelector("#module-597921 > div > div > div:nth-child(2) > div > a > span")).click();
				//System.out.println("Assessment Marks displayed:"+driver.findElement(By.cssSelector("#region-main > div:nth-child(2) > table > tbody > tr > td.cell.c1")).getText());
				System.out.println("Assessment Marks displayed:"+driver.findElement(By.cssSelector("#region-main > div:nth-child(2) > table > tbody > tr > td.cell.c1")).getText());
				System.out.println("Assessment testing successfully completed! Huraaayyy!!!");
				driver.navigate().back();
				
					if(driver.findElement(By.cssSelector("#section-outline-2 > a")).isDisplayed()){
						System.out.println("Assessment 2 is displayed");
						driver.findElement(By.cssSelector("#section-outline-2 > a")).click();
					
						if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[1]/section/div/div/div/ul/li/div/div/ul/li[2]/div/div/div[2]/div/a/span")).isDisplayed()) {
							System.out.println("TTT_C&PST_TB_A3_CONNECTING_THOUGHTS_BETTER is opened ");
							driver.findElement(By.cssSelector("#module-600486 > div > div > div:nth-child(2) > div > a > span")).click();
							System.out.println("Grades obtained:"+driver.findElement(By.cssSelector("#region-main > div:nth-child(2) > table > tbody > tr > td.cell.c1")).getText());
							System.out.println("Assessment 2 testing successfully completed! Huraaayyy!!!");
						}
						else {
							System.out.println("TTT_C&PST_TB_A3_CONNECTING_THOUGHTS_BETTER is not displayed.");
						}
					}
					else {
						System.out.println("Assessment 2 is not displayed");
					}
				}
				else {
					System.out.println("TTT_C&PST_TB_QUIZ_WEEK_12 is not displayed.");
				}
			}
			else {
				System.out.println("Assessment 1 is not displayed");
			}
		}
		
		else {
			System.out.println("Assessments tab is not opened");
		}
	}
	
	@AfterTest
	public void tearDown(){
	driver.quit();
	}
}