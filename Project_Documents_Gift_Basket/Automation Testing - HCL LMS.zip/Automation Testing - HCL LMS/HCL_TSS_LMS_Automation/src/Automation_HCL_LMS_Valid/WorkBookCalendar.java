package Automation_HCL_LMS_Valid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class WorkBookCalendar {
    WebDriver driver;

    @BeforeTest
    @Parameters("browser")
    public void setUp(String browserName)throws Exception{
        if(browserName.equalsIgnoreCase("edge")){
            System.setProperty("webdriver.edge.driver","C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
            driver=new EdgeDriver();
        }
        else if(browserName.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver","C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
            driver=new ChromeDriver();
        }

        //Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
    }

    @Test
    public void testWeb(){

        if(driver.findElement(By.cssSelector("#demoEvoCalendar > div.calendar-inner")).isDisplayed()){
            //Clicking on March 29,2022 in Workbook Calendar
            driver.findElement(By.cssSelector("#demoEvoCalendar > div.calendar-inner > table > tbody > tr:nth-child(7) > td:nth-child(3) > div")).click();

            //Storing and printing the details of the sessions on the selected date
            String text=driver.findElement(By.cssSelector("#demoEvoCalendar > div.calendar-events")).getText();
            System.out.println(text);
        }
        else
            System.out.println("Workbook Calender is not dispalyed");
    }

    @AfterTest()
    public void tearDown(){
        driver.quit();
    }
}