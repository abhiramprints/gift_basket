package Automation_HCL_LMS_Valid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class WordOfDay {
    WebDriver driver=null;
    @Parameters("browser")
    @BeforeTest
    public void setUp(String browserName){
        if(browserName.equalsIgnoreCase("edge")){
            System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
            driver= new EdgeDriver();
        }
        else if(browserName.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
            driver= new ChromeDriver();
        }
    }
    
    @Test
    public void testWeb(){
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
        if(driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/nav/div[2]/ul/li[2]/a")).isDisplayed()){
            System.out.println("WOD option is available.");
            driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/nav/div[2]/ul/li[2]/a")).click();
            if(driver.findElement(By.cssSelector("#dialog > h2")).isDisplayed()){
                System.out.println("Word is present after clicking WOD option");
                String wod=driver.findElement(By.cssSelector("#dialog > h2")).getText();
                System.out.println("Title of the page is: "+driver.getTitle());
                System.out.println("Word of the day:  "+wod);
            }
            else{
                System.out.println("Word is not present after clicking WOD option");
            }
        }
        else{
            System.out.println("Word of the Day option is not available.");
        }

    }
    
    @AfterTest
    public void tearDown(){
        driver.quit();
    }
}