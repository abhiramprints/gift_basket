package Automation_HCL_LMS_Valid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class DailyQuiz_Module {
    WebDriver driver=null;
    @BeforeTest
    @Parameters("browser")
    public void setUp(String browserName){
        if(browserName.equalsIgnoreCase("edge")){
            System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
            driver= new EdgeDriver();
        }
        else if(browserName.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
            driver= new ChromeDriver();
        }
    }
    
    @Test
    public void testWeb(){
    	ValidLogin vl=new ValidLogin();
    	vl.verifyLogin(driver);
    	//Daily Quiz
    	if(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div/section/div/div/div/div[3]/div/div[3]/div/div[1]/div[2]/a")).isDisplayed()){
	    	System.out.println("Daily Quiz link is displayed on Dasboard.");
	    	driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div/section/div/div/div/div[3]/div/div[3]/div/div[1]/div[2]/a")).click();
	    	System.out.println("Daily quiz link is clicked.");
	
	    	for(String winHandle : driver.getWindowHandles()){
	    		driver.switchTo().window(winHandle);
	    	}
	    	
	    	String actual1=driver.getTitle();
	    	String expected1="Course: Daily Quiz";
	    	Assert.assertEquals(actual1, expected1);
	    	
	    	System.out.println("Title:"+driver.getTitle());
	    	if(driver.findElement(By.cssSelector("#section-outline-1 > a")).isDisplayed()) {
		    	System.out.println("Daily Quiz section is present.");
		    	driver.findElement(By.cssSelector("#section-outline-1 > a")).click();
		    	System.out.println("Daily Quiz section is clicked.");
		    	String actual2=driver.getTitle();
		    	String expected2="Course: Daily Quiz, Section: Daily Quiz";
		    	Assert.assertEquals(actual2, expected2);
		    	System.out.println("Title: "+driver.getTitle());
		    	
		    	if(driver.findElement(By.xpath("//*[@id='module-587050']/div/div/div[2]/div")).isDisplayed()){
		    		System.out.println("WQ_QUIZ_CRT_Java_DAY2 is displayed.");
		    		driver.findElement(By.xpath("//*[@id='module-587050']/div/div/div[2]/div/a")).click();
		    		System.out.println("WQ_QUIZ_CRT_Java_DAY2 is clicked.");
		    		String actual3=driver.getTitle();
		    		String expected3="Daily Quiz-2247: WQ_QUIZ_CRT_Java_DAY2";
		    		Assert.assertEquals(actual3, expected3);
		    		System.out.println("Title:"+driver.getTitle());
		
		    		System.out.println("Marks displayed:"+driver.findElement(By.cssSelector("#region-main > div:nth-child(2) > table > tbody > tr > td.cell.c1")).getText());
		    		driver.navigate().back();
		    		
		    		if(driver.findElement(By.xpath("//*[@id='section-outline-2']/a")).isDisplayed()){
			    		System.out.println("Games section is present");
			    		driver.findElement(By.xpath("//*[@id='section-outline-2']/a")).click();
			    		System.out.println("Games section is clicked.");
			    		String actual4=driver.getTitle();
			    		String expected4="Course: Daily Quiz, Section: GAMES";
			    		Assert.assertEquals(actual4, expected4);
			    		System.out.println("Title: "+driver.getTitle());
			    		driver.findElement(By.cssSelector("#module-604653 > div > div > div:nth-child(2) > div > a > span")).click();
			    		System.out.println("Grades obtained:"+driver.findElement(By.cssSelector("#region-main > div:nth-child(2) > table > tbody > tr:nth-child(1) > td.cell.c2")).getText());
			    		System.out.println("Games testing successfully completed!");
		    		}
		    		else
		    		System.out.println("Games section is not present");
		
		    	}
		    	else
		    	System.out.println("WQ_QUIZ_CRT_Java_DAY2 is not displayed.");
	    	}
	    	else
	    	System.out.println("Daily Quiz section is not present.");
    	}
    	else
    	System.out.println("Daily Quiz link is not displayed on Dasboard.");
    }
    
    @AfterTest
    public void tearDown(){
        driver.quit();
    }
}