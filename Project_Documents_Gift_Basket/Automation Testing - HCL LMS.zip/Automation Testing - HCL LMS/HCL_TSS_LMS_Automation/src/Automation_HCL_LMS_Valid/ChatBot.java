package Automation_HCL_LMS_Valid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ChatBot {
	WebDriver driver;
	
	@BeforeTest
	@Parameters("browser")
	public void setUp(String browserName) {
		// Cross Browser Testing
		if(browserName.equalsIgnoreCase("edge")) {
			System.setProperty("webdriver.edge.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
			driver= new EdgeDriver();
		}
		else if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
			driver= new ChromeDriver();
		}
		
		//Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
	}
	
	@Test
	public void testWeb() {
		//Clicking Chatbot
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(driver.findElement(By.linkText("Chatbot")).isDisplayed()) {
			System.out.println("Chat Bot Button is present");
			driver.findElement(By.linkText("Chatbot")).click();
		}
		
		else {
			System.out.println("Chat Bot Button is not present");
		}
		
		//Clicking Robot
		/*driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(driver.findElement(By.cssSelector("#chatImageTag")).isDisplayed()) {
			System.out.println("Chat Bot is present");
			driver.findElement(By.cssSelector("#chatImageTag"));
			driver.findElement(By.id("HCLBot_text")).sendKeys("Hello HCL");
			driver.findElement(By.cssSelector("#HCLBot_send")).click();
		}
		
		else {
			System.out.println("Chat Bot is not present");
		}	
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Chat Bot working fine!");*/
	}
	
	@AfterTest
	public void tearDown() {
		//Printing the active page's Title
		if(driver.getTitle().contains("Learner Landing")) {
			System.out.println("Process completed");
		}
		else
			System.out.println("Process not completed");
		System.out.println("Tested by K Abhiram");
		
		//Closing the active browser
		//driver.quit();
		//K Abhiram
	}
}
