package Automation_HCL_LMS_Valid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class Java_Set {
    WebDriver driver;

    @BeforeTest
    @Parameters("browser")
    public void setUp(String browserName)throws Exception{
        if(browserName.equalsIgnoreCase("edge")){
            System.setProperty("webdriver.edge.driver","C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\edgedriver_win64\\msedgedriver.exe");
            driver=new EdgeDriver();
        }
        else if(browserName.equalsIgnoreCase("chrome")){
            System.setProperty("webdriver.chrome.driver","C:\\Users\\k.abhiram\\Downloads\\HCL TECHBEE NOTES\\TECHBEE CRT OND\\AUTOMATION TESTING PART - 1\\Selenium\\chromedriver_win32\\chromedriver.exe");
            driver=new ChromeDriver();
        }

        //Login
        ValidLogin vl=new ValidLogin();
        vl.verifyLogin(driver);
    }

    @Test
    public void testWeb(){

        //Clicking on Java
        if(driver.findElement(By.xpath("//*[@id=\"region-main\"]/div/div/div/div[2]/div[3]/div[3]/div/div/a/strong")).isDisplayed()){
            driver.findElement(By.xpath("//*[@id=\"region-main\"]/div/div/div/div[2]/div[3]/div[3]/div/div/a/strong")).click();
            for(String winHandle : driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
            }
            System.out.println(driver.getTitle()+" opened");
        }
        else
            System.out.println("Java course is not dispalyed");


        //Selecting module TERM 1 - Module 2: OOPs c...
        if(driver.findElement(By.cssSelector("#section-outline-24 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-24 > a")).click();
            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        }
        else
            System.out.println("Module TERM 1 - Module 2: OOPs c... is not dispalyed");


        //Selecting course Topic 1: OOP, Classes and...
        if(driver.findElement(By.cssSelector("#section-outline-25 > a")).isDisplayed()){
            driver.findElement(By.cssSelector("#section-outline-25 > a")).click();
            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        }
        else
            System.out.println("Topic 1: OOP, Classes and... is not displayed");

        //Selecting In-Class Content-3_OOP
        if(driver.findElement(By.xpath("//*[@id=\"module-579729\"]/div/div/div[2]/div/a/span")).isDisplayed()){
            driver.findElement(By.xpath("//*[@id=\"module-579729\"]/div/div/div[2]/div/a/span")).click();
            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        }
        else
            System.out.println("In-Class Content-3_OOP is not displayed");

        //Clicking on Enter button
        if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isDisplayed()){
            if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isEnabled()){
                driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).click();
                driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
            }
        }
        else
            System.out.println("Enter button is not displayed");

        //Clicking on Exit activity button
        if(driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).isDisplayed()){
            if(driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).isEnabled()){
                driver.findElement(By.xpath("//*[@id=\"page-header\"]/div/div/div/div[2]/div[2]/a")).click();
                driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
            }
        }
        else
            System.out.println("Exit button is not displayed");


        //Selecting In-Class Content-4_Classes_And_Methods_Part
        if(driver.findElement(By.xpath("//*[@id=\"module-579730\"]/div/div/div[2]/div/a/span")).isDisplayed()){
            driver.findElement(By.xpath("//*[@id=\"module-579730\"]/div/div/div[2]/div/a/span")).click();
            driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        }
        else
            System.out.println("In-Class Content-4_Classes_And_Methods_Part is not displayed");

        //Clicking on Enter button
        if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isDisplayed()){
            if(driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).isEnabled()){
                driver.findElement(By.cssSelector("#scormviewform > input.btn.btn-primary")).click();
            }
        }
        else
            System.out.println("Enter button is not displayed");
    }

    @AfterTest
    public void tearDown(){
    	//Printing the active page's Title
    	if(driver.getTitle().contains("Java-2247: 4_Classes_And_Methods_Part-I")) {
    		System.out.println("Process completed");
    	}
   		else
   			System.out.println("Process not completed");
   			System.out.println("Tested by Tushar Prabhakar");
   			
   		//Closing the active browser
		driver.quit();
    	//Tushar Prabhakar
    }
}